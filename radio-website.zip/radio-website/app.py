from flask import Flask, render_template

app = Flask(__name__)

channels = [
    {"name": "Radio Fiji Two", "url": "http://peridot.streamguys.com:7150/RFTwo"},
    {"name": "Mirchi Fiji", "url": "https://peridot.streamguys1.com:7155/MirchiFiji"},
    {"name": "Bula FM", "url": "http://peridot.streamguys.com:7150/Bula"},
    {"name": "Navtarang", "url": "https://stream.fijivillage.com/navtarang"},
    {"name": "Radio Sargam", "url": "https://stream.fijivillage.com/radiosargam"},
    {"name": "2Day FM", "url": "http://peridot.streamguys.com:7150/2Day"}
]

@app.route('/')
def index():
    return render_template('index.html', channels=channels)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
