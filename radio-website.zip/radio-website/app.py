from flask import Flask, render_template, url_for

app = Flask(__name__)

channels = [
    {"name": "Radio Fiji Two", "url": "http://peridot.streamguys.com:7150/RFTwo"},
    {"name": "Mirchi Fiji", "url": "https://peridot.streamguys1.com:7155/MirchiFiji"},
    {"name": "Bula FM", "url": "http://peridot.streamguys.com:7150/Bula"},
    {"name": "Navtarang", "url": "https://stream.fijivillage.com/navtarang"},
    {"name": "Radio Sargam", "url": "https://stream.fijivillage.com/radiosargam"},
    {"name": "Other Fiji Radio", "url": "https://servidor19.brlogic.com:7304/live"}
]

@app.route('/')
def index():
    return render_template('index.html', channels=channels)

if __name__ == '__main__':
    app.run(debug=True)
