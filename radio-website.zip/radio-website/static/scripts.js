let deferredPrompt;
const installBtn = document.getElementById("installApp");

window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installBtn.style.display = "block";
});

installBtn.addEventListener("click", () => {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then(() => {
        deferredPrompt = null;
        installBtn.style.display = "none";
    });
});


function playStation(name, url) {
    const audioPlayer = document.getElementById('audio-player');
    const nowPlaying = document.getElementById('now-playing');
    const spinner = document.getElementById('loading-spinner');

    nowPlaying.textContent = `Now Playing: ${name}`;
    audioPlayer.src = url;
    spinner.style.display = 'inline-block';

    audioPlayer.oncanplay = () => {
        spinner.style.display = 'none';
    };

    audioPlayer.onerror = () => {
        spinner.style.display = 'none';
        alert('Failed to load stream. Please try another station.');
    };

    audioPlayer.play();
}
