window['__onGCastApiAvailable'] = function(isAvailable) {
    if (isAvailable) {
        cast.framework.CastContext.getInstance().setOptions({
            receiverApplicationId: chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID,
            autoJoinPolicy: chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED
        });
    }
};

function playStation(name, url) {
    const audioPlayer = document.getElementById('audio-player');
    const stationName = document.getElementById('now-playing');
    stationName.textContent = `Now Playing: ${name}`;
    audioPlayer.src = url;
    audioPlayer.play();
    updateBackgroundColor(name);
}

function castToDevice() {
    const castContext = cast.framework.CastContext.getInstance();
    const castSession = castContext.getCurrentSession();

    if (castSession) {
        const mediaInfo = new chrome.cast.media.MediaInfo(audioPlayer.src, 'audio/mp3');
        mediaInfo.metadata = new chrome.cast.media.GenericMediaMetadata();
        mediaInfo.metadata.title = document.getElementById('now-playing').textContent;

        const request = new chrome.cast.media.LoadRequest(mediaInfo);
        castSession.loadMedia(request)
            .then(() => console.log('Cast started'))
            .catch((error) => console.error('Error casting:', error));
    } else {
        console.log('No cast session available');
    }
}

function setVolume(volume) {
    document.getElementById('audio-player').volume = volume;
}

function updateBackgroundColor(station) {
    // Simple example for changing background color based on station name
    const colors = {
        'Radio Fiji Two': '#1a1a2e',
        'Mirchi Fiji': '#0f3460',
        'Bula FM': '#16213e',
        'Navtarang': '#f05454',
        'Radio Sargam': '#f77f7f',
        'Other Fiji Radio': '#16213e'
    };
    document.body.style.backgroundColor = colors[station] || '#1a1a2e';
}

async function updateNowPlaying() {
    try {
        const response = await fetch('YOUR_METADATA_API_URL');
        const data = await response.json();
        document.getElementById('now-playing').textContent = `Now Playing: ${data.songTitle}`;
    } catch (error) {
        console.error('Error fetching now playing:', error);
    }
}

setInterval(updateNowPlaying, 30000);
